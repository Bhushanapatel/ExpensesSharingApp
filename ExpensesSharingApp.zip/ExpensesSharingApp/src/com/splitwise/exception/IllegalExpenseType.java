package com.splitwise.exception;

public class IllegalExpenseType extends Exception{
    public IllegalExpenseType(String message) {
        super(message);
    }
}
