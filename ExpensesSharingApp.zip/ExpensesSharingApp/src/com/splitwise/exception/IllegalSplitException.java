package com.splitwise.exception;

public class IllegalSplitException extends Exception {
    public IllegalSplitException(String message){
        super(message);
    }
}

