package com.splitwise.exception;

public class IllegalUserId extends Throwable {
    public IllegalUserId(String message) {
        super(message);
    }
}
