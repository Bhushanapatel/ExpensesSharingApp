package com.splitwise.expense;

public enum ExpenseType {
    EQUAL,
    EXACT,
    PERCENT
}
