
package com.splitwise.split;

public enum SplitType {
    EQUAL,
    PERCENT,
    EXACT
}
